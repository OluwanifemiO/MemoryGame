package com.example.memorygame.Model

import android.content.SharedPreferences

public lateinit var sharedPreferences: SharedPreferences
data class WelcomeModel(
    val playerName: String
)

data class GameModel(
    val playerScore: Int,
    val tilesToRemember: Int,
    val numberOfTiles: Int,
    val selectedTiles: Int,
    val highlightedTiles: Int,
    val correctSelectionCount: Int
)

data class HighScoresModel(
    val playerName: String,
    val score: Int
)

