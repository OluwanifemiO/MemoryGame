package com.example.memorygame.ViewModel

import androidx.lifecycle.ViewModel
import com.example.memorygame.Model.WelcomeModel


class WelcomeViewModel : ViewModel() {

    //if there is a name, save it to the model
    fun saveName(username: String):WelcomeModel
    {
        return WelcomeModel(username)
    }

    //if there is no name entered, set one
    fun setName(): WelcomeModel
    {
        val newName =  "Anonymous Player"
        return WelcomeModel(newName)
    }
}

