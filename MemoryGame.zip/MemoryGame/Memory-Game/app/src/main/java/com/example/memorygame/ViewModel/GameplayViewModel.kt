package com.example.memorygame.ViewModel

import androidx.lifecycle.ViewModel
import kotlin.random.Random

class GameplayViewModel : ViewModel() {

    private val gridSize = 6
    var roundTileCount = 4
    private var highlightedTiles = mutableListOf<Pair<Int, Int>>()

    fun highlightRandomTiles() {
        // Generate and store random tiles to be highlighted
        highlightedTiles = generateRandomTiles(roundTileCount)
    }

    fun getHighlightedTiles(): List<Pair<Int, Int>> {
        return highlightedTiles
    }

    fun increaseTileCount() {
        // Increment the number of tiles for the next round
        if (roundTileCount < gridSize) {
            roundTileCount++
        }
    }

    fun checkUserSelection(selectedTiles: List<Pair<Int, Int>>): Boolean {
        // Check if the user's selection contains all the highlighted tiles
        return highlightedTiles.containsAll(selectedTiles) && selectedTiles.size == highlightedTiles.size
    }
    private fun generateRandomTiles(count: Int): MutableList<Pair<Int, Int>> {
        val random = Random
        val generatedTiles = mutableListOf<Pair<Int, Int>>()

        while (generatedTiles.size < count) {
            val row = random.nextInt(gridSize)
            val col = random.nextInt(gridSize)
            val tile = Pair(row, col)

            if (tile !in generatedTiles) {
                generatedTiles.add(tile)
            }
        }

        return generatedTiles
    }
}
