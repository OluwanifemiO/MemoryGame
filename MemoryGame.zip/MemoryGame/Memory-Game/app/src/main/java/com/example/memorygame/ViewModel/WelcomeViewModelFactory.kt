package com.example.memorygame.ViewModel

import android.content.Context
import androidx.lifecycle.ViewModelProvider

class WelcomeViewModelFactory(private val context: Context) : ViewModelProvider.NewInstanceFactory() {


}