package com.example.memorygame.View

import android.content.Context
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.memorygame.R
import com.example.memorygame.ViewModel.GameplayViewModel

class
GameplayFragment : Fragment() {

    companion object {
        fun newInstance() = GameplayFragment()
    }

    private lateinit var viewModel: GameplayViewModel
    private lateinit var gridLayout: GridLayout
    private lateinit var timerTextView: TextView
    private lateinit var tiles: Array<Array<ImageView>>
    private var selectedTiles = mutableListOf<Pair<Int, Int>>()
    private lateinit var roundTimer: CountDownTimer
    private lateinit var userInputTimer: CountDownTimer
    private var roundCount = 0
    private var correctSelectionCount = 0
    private var userScore = 0
    private lateinit var context: Context
    private lateinit var score: TextView
    private lateinit var numOfTiles: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_gameplay, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(GameplayViewModel::class.java)
        gridLayout = view?.findViewById(R.id.gridLayout)!!
        timerTextView = view?.findViewById(R.id.timer)!!
        score = view?.findViewById((R.id.player_score))!!
        numOfTiles = view?.findViewById((R.id.num_of_tiles))!!

        //create and initialize the grid
        initGrid()
        startGame()
        // TODO: Use the ViewModel


    }

    private fun initGrid() {
        tiles = Array(6) { row ->
            Array(6) { col ->
                val imageView = ImageView(requireContext())
                imageView.layoutParams = GridLayout.LayoutParams().apply {
                    rowSpec = GridLayout.spec(row)
                    columnSpec = GridLayout.spec(col)
                    width = 60.dpToPx()
                    height = 60.dpToPx()
                    setMargins(5.dpToPx(), 5.dpToPx(), 5.dpToPx(), 5.dpToPx())
                }
                imageView.setBackgroundResource(R.color.white)
                imageView.setOnClickListener(View.OnClickListener { onTileClicked(row, col) })
                gridLayout.addView(imageView)
                imageView
            }
        }
    }

    private fun startGame() {
        viewModel.highlightRandomTiles()
        updateGrid()
        startRoundTimer()
    }


    private fun resetTileColors() {
        // Reset the background color of all tiles to default (white)
        for (i in 0 until 6) {
            for (j in 0 until 6) {
                tiles[i][j].setBackgroundResource(R.color.white)
            }
        }
    }


    private fun updateGrid() {
        // Get the randomly highlighted tiles from the viewModel
        val highlightedTiles = viewModel.getHighlightedTiles()

        //set the number of tiles to be the number of highlighted tiles
        numOfTiles.text = viewModel.roundTileCount.toString()

        // Loop through the tile grid to find the selected tiles that match the highlighted tiles
        for (i in 0 until 6) {
            for (j in 0 until 6) {
                if (highlightedTiles.contains(Pair(i, j))) {
                    // Update the background color of highlighted tiles
                    tiles[i][j].setBackgroundResource(R.color.lavender)
                } else {
                    // Reset the background color of non-highlighted tiles to default (white)
                    tiles[i][j].setBackgroundResource(R.color.white)
                }
            }
        }
    }

    //Starts a 5 timer for the round to show the highlighted tiles the user has to memorize
    private fun startRoundTimer() {
        roundTimer = object : CountDownTimer(5000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timerTextView.text = "${millisUntilFinished / 1000}"
            }

            override fun onFinish() {
                clearGridSelection()
                resetTileColors()  // Reset tile colors before starting the user input phase
                showToast("Now, select the highlighted tiles.")
                startUserInputTimer()
            }
        }.start()
    }

    //Starts a 8 second timer the user has to select the matching tiles
    private fun startUserInputTimer() {
        userInputTimer = object : CountDownTimer(8000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                // Update timer text during user input phase
                timerTextView.text = " ${millisUntilFinished / 1000}"
            }

            override fun onFinish() {
                checkUserSelection()
            }
        }.start()
    }


    //click listener to detect when the user clicks on a tile
    private fun onTileClicked(row: Int, col: Int) {
        // Handle tile clicks during user input
        if (selectedTiles.size < 4) {
            selectedTiles.add(Pair(row, col))

            // Update the background color of the clicked tile to indicate selection
            tiles[row][col].setBackgroundResource(R.color.lavender)

            // If the user selected the maximum allowed tiles, check the selection
            if (selectedTiles.size == 4) {
                checkUserSelection()
            }
        }
    }

    //checks the user's selected tile to see if they match, if they do they get 10 points
    private fun checkUserSelection() {
        roundTimer.cancel()
        userInputTimer.cancel()

        if (selectedTiles.size == viewModel.roundTileCount && viewModel.checkUserSelection(selectedTiles)) {
            showToast("Correct! You earned 10 points.")
            userScore += 10
            correctSelectionCount++
            if (correctSelectionCount == 3) {
                showToast("Next round: Select 5 tiles for 20 points each.")
                viewModel.increaseTileCount()
                userScore += 20
                correctSelectionCount = 0
            }
            roundCount++
            showUserScore() // Display the user's score
            startGame()
        } else {
            showToast("Wrong selection! Game over.")
            // Handle game over, update high score, etc.
            handleGameOver()
        }
    }

    private fun showUserScore() {
        score.text = "${userScore}"
    }

    private fun clearGridSelection() {
        for (i in 0 until 6) {
            for (j in 0 until 6) {
                tiles[i][j].isSelected = false
            }
        }
        selectedTiles.clear()
    }

    private fun showToast(message: String) {
        val activityContext = activity
        if (activityContext != null) {
            Toast.makeText(activityContext, message, Toast.LENGTH_SHORT).show()
        }
    }

    //Saves the player's score to the shared preferences to access in the highscores page
    private fun saveScore() {
        val sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val currentScore = userScore

        // Assuming "userScore" is a unique key for storing the score
        editor.putInt("userScore", currentScore)
        editor.apply()
    }

    //this method handles the state where the game is over and
    private fun handleGameOver(){
        saveScore()
        // Provide a message to alert the User
        showToast("Game Over! Your final score is $userScore")
    }

    //This method converts the default ... to pixels
    private fun Int.dpToPx(): Int {
        val scale = resources.displayMetrics.density
        return (this * scale).toInt()
    }

}