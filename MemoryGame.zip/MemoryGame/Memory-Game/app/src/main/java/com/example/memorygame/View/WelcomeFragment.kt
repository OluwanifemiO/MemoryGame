package com.example.memorygame.View

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.media3.common.util.UnstableApi
import com.example.memorygame.R
import com.example.memorygame.ViewModel.WelcomeViewModel

class WelcomeFragment : Fragment() {

    private lateinit var sharedPreferences: SharedPreferences
    private var name = "MySharedPrefs"
    private var message = "Your name has been saved"
    private var editTextUsername: EditText? = null
    private lateinit var btnSave: Button

    companion object {
        fun newInstance() = WelcomeFragment()
    }

    private lateinit var viewModel: WelcomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_welcome, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(WelcomeViewModel::class.java)

        //collect the player's username from the edit text field
        editTextUsername = view?.findViewById(R.id.player_username)

        sharedPreferences = requireActivity().getSharedPreferences(name, Context.MODE_PRIVATE)

        //create a click event listener for the save button
        btnSave = view?.findViewById(R.id.btnSave)!!
        btnSave.setOnClickListener(View.OnClickListener { checkForName() })
    }

    //This function will check if the user entered a name and if they didn't they will be assigned a default one
    @OptIn(UnstableApi::class) private fun checkForName() {
        //convert the text to a string and save it
        val username = editTextUsername?.text.toString()
        // If the user enters a name, save the name to the shared preferences and model

        val editor = sharedPreferences.edit()
        editor.putString("username", username)
        editor.apply()
        viewModel.saveName(username)

        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()


        //sharedPreferences.getString("username", "Anonymous Player")?: "Anonymous Player"

    }

}