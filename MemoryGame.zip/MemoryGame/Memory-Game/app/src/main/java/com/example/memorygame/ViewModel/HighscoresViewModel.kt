package com.example.memorygame.ViewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class HighscoresViewModel(application: Application) : AndroidViewModel(application) {




}