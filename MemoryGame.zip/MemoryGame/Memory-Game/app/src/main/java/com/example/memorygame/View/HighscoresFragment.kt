package com.example.memorygame.View

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.memorygame.R
import com.example.memorygame.ViewModel.HighscoresViewModel

class HighscoresFragment : Fragment() {

    companion object {
        fun newInstance() = HighscoresFragment()
    }

    private lateinit var viewModel: HighscoresViewModel
    private lateinit var playerNameTextView: TextView
    private lateinit var playerScoreTextView: TextView
    private var nameForPlayerName = "MySharedPrefs"
    private var nameForPlayerScore = "MyPrefs"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_highscores, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(HighscoresViewModel::class.java)
        playerScoreTextView = view?.findViewById(R.id.high_score1score)!!
        playerNameTextView = view?.findViewById(R.id.high_score1name)!!

        //read player name and score from the shared preferences
        val playerName = readPlayerNameFromPreferences()
        val playerScore = readPlayerScoreFromPreferences()

        //update the text views
        playerScoreTextView.text = "$playerScore"
        playerNameTextView.text = "$playerName"
    }

    private fun readPlayerNameFromPreferences(): String {
        // Read player name from SharedPreferences
        return requireContext().getSharedPreferences(nameForPlayerName, Context.MODE_PRIVATE)
            .getString("username", "Anonymous Player") ?: "Anonymous Player"
    }

    private fun readPlayerScoreFromPreferences(): Int {
        // Read player score from SharedPreferences
        return requireContext().getSharedPreferences(nameForPlayerScore, Context.MODE_PRIVATE)
            .getInt("userScore", 0)
    }
}